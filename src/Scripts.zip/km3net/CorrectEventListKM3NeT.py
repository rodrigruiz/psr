""" Performs barycentric and binary corrections on TimeSeries object generated from KM3NeT data.

Usage: CorrectEventListKM3NeT.py -i INPUT_FILES... [--wildcard] -o OUTPUT_DIR -s SOURCE_SPECS_FILE

Options:
  -h --help                              Help
  -i --input_files INPUT_FILES           Input files
  -o --output_dir OUTPUT_DIR             Output directory
  -s --source SOURCE_SPECS_FILE          Hdf5 file containing information about the source of interest (ra, dec, P_orb, ...)     
"""
#python3 psr/src/scripts/CorrectEventListKM3NeT.py -i '/home/hpc/capn/capn107h/software/eventlistTestOutput/mcv*' -o correctedeventlistTestOutput/ -s hdf5SourceFiles/Vela_X-1.h5

from docopt import docopt
import os, glob
import h5py as h5py
import re
import numpy as np
from astropy.time import Time, TimeDelta
from astropy.timeseries import BinnedTimeSeries
import astropy.units as u
import astropy.coordinates as coord
from astropy.coordinates import EarthLocation, SkyCoord, Angle
from astropy.table import Table



# PLENS Imports
import plens.TimeSeries as TS
import plens.EventList as EL
from plens.TimeSeries import orbit_cor_deeter
import plens.antares_hdf5
import plens.antares_hdf5 as antares_hdf5




def main():
    # Getting Key-Argument-Pairs that are passed to the script
    arguments = docopt(__doc__)

    data = {}
    for key in arguments:
        data[key.replace("-", "")] = arguments[key]
    
    input_files = arguments['--input_files']

    if not os.path.exists(data['output_dir']):
        os.makedirs(data['output_dir'])


    
    
    # Reading data files with source information
    with h5py.File(data['source'], 'r') as f:
        # Source name
        source_name = f['source_name'][()]
        print("Source Name:", source_name)

        # SkyCoord information
        ra = f['skycoord/ra'][()]
        dec = f['skycoord/dec'][()]
        skycoord = SkyCoord(ra=ra*u.deg, dec=dec*u.deg)
        print("SkyCoord:", skycoord)

        Porb = f['P_orb'][()]
        print("Orbital Period:", Porb, "days")
        
        Tpi2 = f['T_pi2'][()]
        axsini = f['axsini'][()]
        e = f['e'][()]
        omega = f['omega'][()]

    for file in input_files:
        # Fetching filename for usage in output filename 
        folder_path, file_name = os.path.split(file)
        file_name = os.path.splitext(file_name)[0]

        output_file = data['output_dir'] + file_name + '_corrected.hdf5'
        print(output_file, os.path.exists(output_file))

        # Read TimeSeries file and apply corrections using timing and source information
        with h5py.File(file) as input_file:
            # Read non-corrected event list
            EventList = EL.readEventList(input_file)
            
            # Assuming 'time' is a column in the EventList, which is an astropy Time object
            TimeSeries = EventList['time']  # Ensure this is an Astropy Time object

            
            print("Raw TimeSeries:")
            print(TimeSeries)

            # Perform the barycentric correction on the extracted time values
            BaryCorrectedTimes = EL.barycentric_correction(EventList, skycoord)
            print("After Barycentric Correction:")
            print(BaryCorrectedTimes)

            # Binary correction
            time_corr = orbit_cor_deeter(
                BaryCorrectedTimes.time.value, 
                (float(Porb) * u.d).to_value(u.s), 
                float(axsini), 
                float(e), 
                Angle(float(omega), u.deg).radian - np.pi / 2, 
                Time(float(Tpi2) + float(Porb) / 2, format='jd').unix
            )

            # Creating new table with corrected eventlist
            CorrectedEventList = EventList.copy()
            CorrectedEventList['time'] = time_corr  # Apply corrected times
            print("After Binary Corrections:")
            print(CorrectedEventList)

        if os.path.exists(output_file):
            os.remove(output_file)  # Remove the file if it already exists

        # Store Corrected TimeSeries in HDF5-File
        with h5py.File(output_file, 'w') as output:   
            CorrectedEventList.write(output, format='hdf5', overwrite=True, serialize_meta=True)

    
if __name__ == "__main__":
    main()
    