"""Inject an artificial signal and apply cuts and time selection and epoch folding algorithm for sensitivity study.
Usage: SensitivityStudyKM3NeT.py 
""" 
import os
import glob
from docopt import docopt

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import h5py 

import astropy.units as u
from astropy.coordinates import SkyCoord, AltAz, EarthLocation
from astropy.time import Time
from astropy.table import Table
from astropy.timeseries import TimeSeries

from plens.PulseModel import MVMD, sinusoid
from stingray import EventList, Lightcurve

import matplotlib.pyplot as plt

from stingray.pulse.search import epoch_folding_search, z_n_search, search_best_peaks
from epochfolding.stingray_epochfolding import savehdf5, get_testfrequencies
from epochfolding.gtis import loadGTIs, saveGTIs

from km3astro.frame import get_location
import km3io.definitions as kd


def load_histogram(file_path):
    with h5py.File(file_path, 'r') as f:
        hist2d = f['hist2d'][()]
        bins_true = f['bins_true'][()]
        bins_reco = f['bins_reco'][()]
    return hist2d, bins_true, bins_reco

def powerLawFlux(E, Phi0, gamma, E0=1e5):
    """
    Returns differential flux at energy E [GeV], normalized at E0 [GeV].
    Phi0 in units of GeV^-1 cm^-2 s^-1 sr^-1.
    """
    return Phi0 * (E / E0) ** (-gamma)

def load_aeff(file_path, flavor):
    with h5py.File(file_path, 'r') as f:

        aeff_1d = f[flavor]['aeff_1d'][()]
        aeff_2d = f[flavor]['aeff_2d'][()]
        e_bins = f['energy_bins'][()]
        costh_bins = f['cos_theta_bins'][()]
    return aeff_1d, aeff_2d, e_bins, costh_bins


def simulate_events_with_2d_aeff(
    phi0,
    energy_bins,
    aeff_2d,
    theta_bin_edges,
    source_coord,
    times,
    location,
    gamma=1.5,
    T=1e6,
    Omega=2*np.pi,
    n_events=None,
    E0=1e5,
    plot=False
):
    from astropy.coordinates import AltAz
    from astropy.time import Time

    E_centers = 0.5 * (energy_bins[:-1] + energy_bins[1:])
    dE = np.diff(energy_bins)

    flux = powerLawFlux(E_centers, phi0, gamma)

    # Convert RA/Dec to AltAz
    altaz_frame = AltAz(obstime=Time(times), location=location)
    source_altaz = source_coord.transform_to(altaz_frame)
    theta_vals = (90 * u.deg - source_altaz.alt).to(u.rad).value

    weights = np.zeros_like(E_centers)

    dt = T / len(theta_vals)  # assume uniform time sampling

    for theta in theta_vals:
        theta_idx = np.digitize(theta, theta_bin_edges) - 1
        theta_idx = np.clip(theta_idx, 0, aeff_2d.shape[1] - 1)
        aeff_theta = aeff_2d[:, theta_idx]
        weights += flux * aeff_theta * dE * dt * Omega

    MAX_EVENTS = int(1e8)
    if n_events is None:
        expected_total = np.sum(weights)
        n_events = np.random.poisson(expected_total)
        if n_events > MAX_EVENTS:
            print(f"Warning: n_events={n_events} is very large; truncating to {MAX_EVENTS}.")
            n_events = MAX_EVENTS

    if n_events == 0:
        if plot:
            print("No events to simulate (n_events=0).")
        return np.array([]), 0

    p_bins = weights / np.sum(weights)
    sampled_bins = np.random.choice(len(p_bins), size=n_events, p=p_bins)

    log_E_low = np.log10(energy_bins[sampled_bins])
    log_E_high = np.log10(energy_bins[sampled_bins + 1])
    simulated_logE = np.random.uniform(log_E_low, log_E_high)
    simulated_energies = 10**simulated_logE

    if plot:
        plt.figure(figsize=(8,5))
        plt.hist(simulated_energies, bins=energy_bins, histtype='step', color='blue', lw=1.5)
        plt.xscale('log')
        plt.yscale('log')
        plt.xlabel("Energy [GeV]")
        plt.ylabel("Number of events")
        plt.title(f"Simulated Detected Event Energies\nPhi0={phi0:.1e}, gamma={gamma}")
        plt.grid(True, which='both', ls='--', alpha=0.5)
        plt.tight_layout()
        plt.show()

    return simulated_energies, n_events

def plot_event_counts_vs_energy_and_phi0_with_contours(
    phi0_values,
    energy_bins,
    mean_A_eff,
    gamma=1.5,
    T=1e6,
    Omega=2*np.pi,
    contour_levels=None,
    log_counts=True,
    E0=1e5,
    plot=False
):
    """
    Plots a 2D heatmap: event counts per energy bin vs. phi0, with optional contour overlays.

    Parameters:
    - phi0_values: array of flux normalization values [cm⁻² s⁻¹ sr⁻¹ GeV⁻¹]
    - energy_bins: array of energy bin edges [GeV]
    - mean_A_eff: array of mean effective areas per energy bin [cm²]
    - gamma: power-law index
    - T: exposure time [s]
    - Omega: solid angle [sr]
    - contour_levels: list of contour levels (in raw counts, not log10)
    - log_counts: whether to plot log10(counts)
    - E0: normalization energy [GeV]
    - plot: bool, if True will generate the plot
    """
    E_centers = np.sqrt(energy_bins[:-1] * energy_bins[1:])
    dE = np.diff(energy_bins)

    counts_matrix = []
    for phi0 in phi0_values:
        flux = powerLawFlux(E_centers, phi0, gamma) # phi0 * (E_centers / E0) ** (-gamma)
        counts = flux * mean_A_eff * T * dE * Omega
        counts_matrix.append(counts)

    counts_matrix = np.array(counts_matrix)  # shape: (len(phi0_values), len(energy_bins)-1)

    if not plot:
        return counts_matrix

    # For plotting
    logE = np.log10(E_centers)
    logPhi0 = np.log10(phi0_values)
    X, Y = np.meshgrid(logE, logPhi0)

    Z = counts_matrix
    if log_counts:
        Z = np.where(Z > 0, Z, 1e-10)
        Z_plot = np.log10(Z)
    else:
        Z_plot = Z

    # Plot heatmap
    plt.figure(figsize=(10, 6))
    cmap = 'viridis'
    im = plt.imshow(Z_plot, aspect='auto', origin='lower',
                    extent=[logE.min(), logE.max(), logPhi0.min(), logPhi0.max()],
                    cmap=cmap)

    plt.xlabel("log10(Energy [GeV])")
    plt.ylabel("log10(Phi₀ [cm⁻² s⁻¹ sr⁻¹ GeV⁻¹])")
    cbar_label = "log10(Event Counts)" if log_counts else "Event Counts"
    plt.colorbar(im, label=cbar_label)

    # Add contours if requested
    if contour_levels is not None:
        contour_vals = np.log10(contour_levels) if log_counts else contour_levels
        CS = plt.contour(X, Y, Z_plot, levels=contour_vals, colors='white', linewidths=1.5)
        plt.clabel(CS, fmt=lambda v: f"{10**v:.0f}" if log_counts else f"{v:.0f}", inline=True, fontsize=10)

    plt.title("Expected Event Counts per Energy Bin vs. Phi₀")
    plt.grid(True, which='both', ls='--', alpha=0.4)
    plt.tight_layout()
    plt.show()


def plot_event_energies(df_events, energy_bins, total_energies,phi0, plot_config=None):
    """
    Plot event energy distributions per flavor, total flux, and shaded regions
    for total showers and tracks.

    Parameters:
        df_events (pd.DataFrame): Must contain 'energy', 'flavor', 'event_type'
        energy_bins (array-like): Energy bin edges
        total_energies (array-like): All energies combined (for total flux)
        plot_config (dict, optional): Style configuration for plotting
    """
    if plot_config is None:
        plot_config = {
            "flavors": {
                "nue":    {"color": "darkblue", "label": r"$\nu_e$",   "linestyle" : "-",   "linewidth": 1.5},
                "anue":   {"color": "darkblue",     "label": r"$\bar\nu_e$",  "linestyle" : "dotted",    "linewidth": 2},
                "numu":   {"color": "firebrick",      "label":r"$\nu_\mu$",  "linestyle" : "-",     "linewidth": 1.5},
                "anumu":  {"color": "firebrick",        "label": r"$\bar\nu_\mu$",  "linestyle" : "dotted",    "linewidth": 2},
                "nutau":  {"color": "gold",     "label": r"$\nu_\tau$",   "linestyle" : "-",    "linewidth": 1.5},
                "anutau": {"color": "gold", "label": r"$\bar\nu_\tau$",   "linestyle" : "dotted",   "linewidth": 2},
            },
            "shower_fill": {
                "color": "skyblue",
                "alpha": 0.8,
                "label": "Total showers"
            },
            "track_fill": {
                "color": "salmon",
                "alpha": 0.4,
                "label": "Total tracks"
            },
            "total_line": {
                "color": "black",
                "linewidth": 2,
                "label": "Total flux",
                "linestyle":  "-"
            }
        }

    # Midpoints for fill_between
    energy_vals = 0.5 * (energy_bins[:-1] + energy_bins[1:])

    plt.figure(figsize=(10, 6))

    

    # Count bin entries
    def bin_counts(energies):
        return np.histogram(energies, bins=energy_bins)[0]

    # Fill: shower and track totals
    shower_energies = df_events[df_events["event_type"] == "shower"]["energy"]
    track_energies = df_events[df_events["event_type"] == "track"]["energy"]

    shower_counts = bin_counts(shower_energies)
    track_counts = bin_counts(track_energies)

    plt.fill_between(
        energy_vals,
        track_counts,
        step='mid',
        color=plot_config["track_fill"]["color"],
        alpha=plot_config["track_fill"]["alpha"],
        label=plot_config["track_fill"]["label"]
    )

    plt.fill_between(
        energy_vals,
        shower_counts,
        step='mid',
        color=plot_config["shower_fill"]["color"],
        alpha=plot_config["shower_fill"]["alpha"],
        label=plot_config["shower_fill"]["label"]
    )

    # Plot each flavor
    for flavor in df_events["flavor"].unique():
        energies = df_events[df_events["flavor"] == flavor]["energy"]
        style = plot_config["flavors"].get(flavor, {})
        plt.hist(
            energies,
            bins=energy_bins,
            histtype='step',
            linewidth=style.get("linewidth", 1.0),
            color=style.get("color", "gray"),
            label=style.get("label", flavor),
            linestyle = style.get("linestyle", "-") 
        )

    # Plot total flux
    plt.hist(
        total_energies,
        bins=energy_bins,
        histtype='step',
        linewidth=plot_config["total_line"]["linewidth"],
        color=plot_config["total_line"]["color"],
        label=plot_config["total_line"]["label"],
        linestyle = plot_config["total_line"]["linestyle"]
    )

    # Final plot styling
    plt.xscale('log')
    plt.yscale('log')
    plt.xlabel("Energy [GeV]")
    plt.ylabel("Number of events")
    plt.title("Simulated Detected Events by Flavor & Type")
    plt.grid(True, which='both', ls='--', alpha=0.5)
    plt.legend(loc='best', fontsize='small')
    plt.tight_layout()
    plt.savefig(f"detected_energies_from_simulated_flux_phi0{phi0}.png")


def simulate_events_all_flavors(
    phi0,
    energy_bins,
    theta_bin_edges,
    aeff_dict,
    source_coord,
    times,
    location,
    gamma=1.5,
    days=90,
    Omega=2*np.pi,
    n_events=None,
    E0=1e5,
    plot=False,
    plot_config=None
):
    total_events = 0
    total_energies = []
    event_records = []
    shower_energies = []
    track_energies = []

    T = days * 86400  # observation time in seconds

    FLAVOR_EVENTTYPE_MAP = {
        "nue": "shower",
        "anue": "shower",
        "numu": "track",
        "anumu": "track",
        "nutau": "shower",
        "anutau": "shower"
    }

    n_flavors = len(aeff_dict)
    phi0_per_flavor = phi0 / n_flavors

    for flavor, aeff_2d in aeff_dict.items():
        simulated_energies, n_evt = simulate_events_with_2d_aeff(
            phi0=phi0_per_flavor,
            energy_bins=energy_bins,
            aeff_2d=aeff_2d,
            theta_bin_edges=theta_bin_edges,
            source_coord=source_coord,
            times=times,
            location=location,
            gamma=gamma,
            T=T,
            Omega=Omega,
            n_events=None,
            E0=E0,
            plot=False
        )

        total_events += n_evt
        total_energies.extend(simulated_energies)

        event_type = FLAVOR_EVENTTYPE_MAP.get(flavor, "shower")
        if event_type == "shower":
            shower_energies.extend(simulated_energies)
        elif event_type == "track":
            track_energies.extend(simulated_energies)

        records = [
            {
                "energy": energy,
                "flavor": flavor,
                "event_type": event_type
            }
            for energy in simulated_energies
        ]
        event_records.extend(records)

    df_events = pd.DataFrame(event_records)

    # Count EM shower events (nu_e and anti_nu_e)
    em_shower_events = df_events[df_events["flavor"].isin(["nue", "anue"])].shape[0]
    print("em_shower_events: ", em_shower_events)
    print("df_events: ", df_events)

    if plot and len(total_energies) > 0:
        plot_event_energies(df_events, energy_bins, total_energies,phi0, plot_config)

    return (
        np.array(total_energies),
        total_events,
        em_shower_events,
        df_events,
        np.array(shower_energies),
        np.array(track_energies)
    )


def simulate_detected_event_energies_from_flux(
    phi0,
    energy_bins,
    mean_A_eff,
    gamma=1.5,
    T=1e6,
    Omega=2*np.pi,
    n_events=None,
    E0=1e5,
    plot=False
):
    """
    Simulates detected event energies based on folded flux × effective area, with optional automatic estimation of n_events.
    
    Parameters:
    - phi0: flux normalization [cm⁻² s⁻¹ sr⁻¹ GeV⁻¹]
    - energy_bins: array of energy bin edges [GeV]
    - mean_A_eff: array of mean effective areas per energy bin [cm²]
    - gamma: spectral index
    - T: exposure time [s]
    - Omega: solid angle [sr]
    - n_events: number of events to simulate (if None, sample from Poisson of expected)
    - E0: normalization energy [GeV]
    - plot: bool, if True will plot the simulated energy distribution

    Returns:
    - simulated_energies: array of sampled event energies [GeV]
    - n_events: number of events simulated
    """
    E_centers = 0.5*(energy_bins[:-1] + energy_bins[1:])
    dE = np.diff(energy_bins)

    flux = powerLawFlux(E_centers, phi0, gamma) # phi0 * (E_centers / E0) ** (-gamma)
    weights = flux * mean_A_eff * T * dE * Omega

    MAX_EVENTS = int(1e8)
    if n_events is None:
        expected_total = np.sum(weights)
        n_events = np.random.poisson(expected_total)
        if n_events > MAX_EVENTS:
            print(f"Warning: n_events={n_events} is very large; truncating to {MAX_EVENTS}.")
            n_events = MAX_EVENTS


    if n_events == 0:
        if plot:
            print("No events to simulate (n_events=0).")
        return np.array([]), 0

    p_bins = weights / np.sum(weights)

    sampled_bins = np.random.choice(len(p_bins), size=n_events, p=p_bins)

    log_E_low = np.log10(energy_bins[sampled_bins])
    log_E_high = np.log10(energy_bins[sampled_bins + 1])
    simulated_logE = np.random.uniform(log_E_low, log_E_high)
    simulated_energies = 10**simulated_logE

    if plot:
        plt.figure(figsize=(8,5))
        plt.hist(simulated_energies, bins=energy_bins, histtype='step', color='blue', lw=1.5)
        plt.xscale('log')
        plt.yscale('log')
        plt.xlabel("Energy [GeV]")
        plt.ylabel("Number of events")
        plt.title(f"Simulated Detected Event Energies\nPhi0={phi0:.1e}, gamma={gamma}")
        plt.grid(True, which='both', ls='--', alpha=0.5)
        plt.tight_layout()
        plt.show()

    return simulated_energies, n_events




from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

# Functions to fit to the angular resolution distribution
def logistic_function(E, a, b, c, d,e,f):
    return a / (1.0 + np.exp(-b * (np.log10(E) - c))) + d + e * np.maximum(0, np.log10(E) - f)

def polynomial(E, a, b, c, d, e, f, g, h):
    return a * np.log10(E)**4 + b * np.log10(E)**3 + c * np.log10(E)**2 + d * np.log10(E) + e + f*np.log10(E)**5 +g * np.log10(E)**6 +h*np.log10(E)**7





# Function to read HDF5 file and fit the data to a model
def fit_angular_resolution(file_path, output_dir, energy_low, energy_high, fit_type="logistic",plot=False):
    # Open the HDF5 file
    table = Table.read(file_path, format='hdf5')

    # Access the columns by their names
    energy_bin_centers = table['energy_bin_center']
    angular_resolution = table['median_angular_separation']
    sigma1_width = table['sigma1_width']  # Assuming this is the uncertainty

    valid_indices = np.isfinite(angular_resolution) & np.isfinite(sigma1_width) & np.isfinite(energy_bin_centers)

    if not np.all(valid_indices):
        print("Warning: Some values were NaN or Inf and have been removed from the fit.")
        energy_bin_centers = energy_bin_centers[valid_indices]
        angular_resolution = angular_resolution[valid_indices]
        sigma1_width = sigma1_width[valid_indices]



    if fit_type == "logistic":
        # Initial guesses for the logistic function parameters
        popt, _ = curve_fit(logistic_function, energy_bin_centers, angular_resolution, 
                            p0=[2, -1, 4, 0.1,1.0, 8], sigma=sigma1_width, absolute_sigma=True)
        fit_func = lambda E: logistic_function(E, *popt)
        plot_name = os.path.join(output_dir,f"fitted_angular_resolution_tracklike.png")
    elif fit_type == "polymial":
        # Initial guesses for the sinusoidal function parameters
        popt, _ = curve_fit(polynomial, energy_bin_centers, angular_resolution, p0=[0.0,0.0,0.05,-0.3,1.0,0.0,0.0,0.0] ,sigma=sigma1_width, absolute_sigma=True)
        fit_func = lambda E: polynomial(E, *popt)
        plot_name = os.path.join(output_dir,f"fitted_angular_resolution_showerlike.png")
    else:
        raise ValueError("Unknown fit type. Choose 'logistic' or 'polymial'.")
    
    if plot == True:
        # Plot the data and the fit
        plt.figure(figsize=(10, 6))
        plt.plot(energy_bin_centers, angular_resolution, color='black', marker='o', linestyle='none', label='Data')
        energy_fit = np.logspace(energy_low, energy_high, 1000)  # Energy values for plotting the fit
        plt.plot(energy_fit, fit_func(energy_fit), color='firebrick', linestyle='-', linewidth=2, label='Fit')
        plt.xscale('log')
        # Add a shaded 1σ band for uncertainties (optional, depends on your data)
        sigma1_band_lower = angular_resolution - sigma1_width  # Example: replace sigma1_values with your actual 1σ uncertainties
        sigma1_band_upper = angular_resolution + sigma1_width
        plt.fill_between(energy_bin_centers, sigma1_band_lower, sigma1_band_upper, color='blue', alpha=0.3, label='1σ Band')

        # Add a shaded 2σ band for uncertainties (optional)
        sigma2_band_lower = angular_resolution - 2*sigma1_width   # Example: replace sigma2_values with your actual 2σ uncertainties
        sigma2_band_upper = angular_resolution + 2*sigma1_width
        plt.fill_between(energy_bin_centers, sigma2_band_lower, sigma2_band_upper, color='blue', alpha=0.1, label='2σ Band')


        plt.xscale('log')
        # Customize labels and title
        plt.xlabel('Energy [GeV]', fontsize=12)
        plt.ylabel('Angular Resolution [°]', fontsize=12)
        plt.title(f'Angular Resolution vs Energy ({fit_type} Fit Type)', fontsize=14)
        # Add gridlines for better readability
        plt.grid(True, which="both", linestyle="--", linewidth=0.7)
        plt.legend()
        plt.savefig(plot_name)

    return fit_func

def sample_reco_energy_array(true_energies, hist2d, bins_true, bins_reco):
    """
    Samples reconstructed energies for an array of true energies based on a 2D histogram.

    Parameters:
    - true_energies: array-like, true neutrino energies
    - hist2d: 2D array of shape (n_true_bins, n_reco_bins), probability distribution
    - bins_true: edges of true energy bins
    - bins_reco: edges of reco energy bins

    Returns:
    - reco_samples: sampled reconstructed energies
    - failed_mask: boolean mask for entries that failed to sample (outside bin range or empty PDF)
    """
    true_energies = np.asarray(true_energies)
    reco_samples = np.full_like(true_energies, np.nan, dtype=float)

    for i, E_true in enumerate(true_energies):
        true_bin_idx = np.digitize(E_true, bins_true) - 1

        # Check if within valid range
        if 0 <= true_bin_idx < hist2d.shape[0]:
            slice_hist = hist2d[true_bin_idx, :]
            if np.sum(slice_hist) > 0:
                pdf = slice_hist / np.sum(slice_hist)
                reco_bin_idx = np.random.choice(len(pdf), p=pdf)

                # Sample uniformly in the selected reco bin
                reco_lo = bins_reco[reco_bin_idx]
                reco_hi = bins_reco[reco_bin_idx + 1]
                reco_samples[i] = np.random.uniform(reco_lo, reco_hi)

    failed_mask = np.isnan(reco_samples)
    return reco_samples, failed_mask


def sample_reco_directions_from_source_skycoord(
    source_coord,
    reco_energies,
    resolution_func,
    detector_location,
    observation_time
):
    """
    Simulate reconstructed directions (zenith, azimuth) around a source SkyCoord.

    Parameters:
    - source_coord: SkyCoord
        The true source celestial coordinate.
    - reco_energies: np.ndarray
        Reconstructed energies for the injected events.
    - resolution_func: callable
        Function that maps energy to angular resolution in degrees.
    - detector_location: EarthLocation
        Location of the detector.
    - observation_time: Time or float
        Observation time (astropy Time or UNIX timestamp).

    Returns:
    - dict with 'zenith', 'azimuth', 'zenith_true', 'azimuth_true', 'separation'
    """

    # Ensure time is Time object
    if isinstance(observation_time, (float, int)):
        observation_time = Time(observation_time, format='unix')

    n_events = len(reco_energies)
    ang_res_deg = resolution_func(reco_energies)  # e.g., 1-40 deg

    # Create duplicated SkyCoord array for source
    source_coords = SkyCoord(
        ra=np.full(n_events, source_coord.ra.degree) * u.deg,
        dec=np.full(n_events, source_coord.dec.degree) * u.deg,
        frame='icrs'
    )

    # Convert angular resolution (in deg) to radians and sample points
    angular_offsets = np.random.normal(loc=0, scale=ang_res_deg, size=n_events) * u.deg
    position_angles = np.random.uniform(0, 360, size=n_events) * u.deg

    # Offset the source in RA/Dec by these angles
    smeared_coords = source_coords.directional_offset_by(position_angles, angular_offsets)

    # Transform to AltAz (local detector frame)
    altaz_frame = AltAz(obstime=observation_time, location=detector_location)
    smeared_altaz = smeared_coords.transform_to(altaz_frame)
    true_altaz = source_coord.transform_to(altaz_frame)

    azimuths = smeared_altaz.az.to(u.deg).value
    zeniths = (90 * u.deg - smeared_altaz.alt).to(u.deg).value

    # Also return true direction
    az_true = true_altaz.az.to(u.deg).value
    zen_true = (90 * u.deg - true_altaz.alt).to(u.deg).value

    return {
        'zenith': zeniths,
        'azimuth': azimuths,
        'zenith_true': np.full(n_events, zen_true),
        'azimuth_true': np.full(n_events, az_true),
        'skycoord': smeared_coords,
        'separation': smeared_coords.separation(source_coord).to(u.deg).value
    }
def inject_signal_times(time, energy, zenith, azimuth, reco_energies_to_inject, reco_types_to_inject, bin_time, pulseshape, frequency,
                        baseline, a, phi, method='classic', kappa=None, num_periods=20, plot=False,
                        skycoord=None, detector_location=None, print_summary=True, preview_n=5, track_resolution_func = None, shower_resolution_func = None):
    """
    Injects signal times into an event list and returns the combined times, energies, and directions.
    Optionally prints a summary of event counts and previews a few example events.

    Parameters:
        ...
        print_summary : bool
            Whether to print a summary of the injection process.
        preview_n : int
            Number of randomly selected events to print as a preview.
    """
    n_events_inject = len(reco_energies_to_inject)
    total_events = len(time)
    num_original_events_to_keep = total_events - n_events_inject

    if num_original_events_to_keep < 0:
        raise ValueError("Number of injected events exceeds original events.")

    # --- Injection process ---
    if method == 'classic':
        high_res_bin_time = 1e-1
        high_res_time = np.arange(time.min(), time.max(), high_res_bin_time)

        if pulseshape == 'mvm':
            counts = MVMD(high_res_time, frequency, phi, kappa, a, baseline=baseline)
        elif pulseshape == 'sine':
            counts = sinusoid(high_res_time, frequency, baseline, a, phi)
        else:
            raise ValueError("Invalid pulseshape")

        lc_original = Lightcurve(high_res_time, counts, dt=high_res_bin_time / 10, skip_checks=True)
        ev = EventList()
        ev.simulate_times(lc_original)
        new_event_times = ev.time

    elif method == 'base':
        start_time = time.min()
        base_interval_length = num_periods / frequency
        high_res_time = np.arange(start_time, start_time + base_interval_length, bin_time)

        if pulseshape == 'mvm':
            counts = MVMD(high_res_time, frequency, phi, kappa, a, baseline=baseline)
        elif pulseshape == 'sine':
            counts = sinusoid(high_res_time, frequency, baseline, a, phi)
        else:
            raise ValueError("Invalid pulseshape")

        lc_base = Lightcurve(high_res_time, counts, dt=bin_time, skip_checks=True)
        ev = EventList()
        ev.simulate_times(lc_base)
        base_event_times = ev.time

        total_time_span = time.max() - time.min()
        num_intervals = int(np.ceil(total_time_span / base_interval_length))
        chosen_base_times = np.random.choice(base_event_times, n_events_inject, replace=True)
        random_shifts = np.random.randint(0, num_intervals, size=n_events_inject) * base_interval_length
        new_event_times = chosen_base_times + random_shifts

    else:
        raise ValueError("Invalid method: choose 'classic' or 'base'")

    # --- Resample injected events if needed ---
    if len(new_event_times) >= n_events_inject:
        indices_to_keep_new = np.random.choice(len(new_event_times), n_events_inject, replace=False)
    else:
        indices_to_keep_new = np.random.choice(len(new_event_times), n_events_inject, replace=True)
    new_event_times = new_event_times[indices_to_keep_new]

    # --- Select original events to keep ---
    indices_to_keep_original = np.random.choice(len(time), num_original_events_to_keep, replace=False)
    remaining_original_times = time[indices_to_keep_original]
    remaining_original_energies = energy[indices_to_keep_original]
    remaining_original_zeniths = zenith[indices_to_keep_original]
    remaining_original_azimuths = azimuth[indices_to_keep_original]

    assert len(reco_types_to_inject) == len(reco_energies_to_inject), "Mismatch between types and energies"

    def resolution_func_per_event(energies):
        # Input: array of energies
        # Output: array of angular resolutions
        resolutions = np.zeros_like(energies)
        mask_track = np.array(reco_types_to_inject) == 'track'
        mask_shower = np.array(reco_types_to_inject) == 'shower'
        
        resolutions[mask_track] = track_resolution_func(np.array(energies)[mask_track])
        resolutions[mask_shower] = shower_resolution_func(np.array(energies)[mask_shower])
        
        return resolutions

    # --- Sample directions for injected events ---
    reco_dirs = sample_reco_directions_from_source_skycoord(
        source_coord=skycoord,
        reco_energies=reco_energies_to_inject,
        #resolution_func=lambda e: 0.5,  # 5 deg resolution for now
        resolution_func = resolution_func_per_event,
        detector_location=detector_location,
        observation_time=Time(new_event_times, format='unix')
    )

    def plot_reco_directions(result, title="Reconstructed Directions"):
        zen = result['zenith']
        az = result['azimuth']
        zen_true = result['zenith_true'][0]
        az_true = result['azimuth_true'][0]

        fig, ax = plt.subplots(figsize=(6, 6))
        sc = ax.scatter(az, zen, s=2, alpha=0.5, label='Reconstructed Events', color='blue')
        ax.plot(az_true, zen_true, marker='*', color='red', markersize=5, label='Source')

        ax.set_xlim(0, 360)
        ax.set_ylim(0, 180)
        ax.set_xlabel("Azimuth (°)")
        ax.set_ylabel("Zenith (°)")
        ax.set_title(title)
        ax.legend()
        ax.grid(True)
        plt.tight_layout()

        plt.show()
    if plot == True:
        plot_reco_directions(reco_dirs)

    
    new_event_zeniths = reco_dirs['zenith']
    new_event_azimuths = reco_dirs['azimuth']

    # --- Combine and sort ---
    combined_times = np.concatenate((remaining_original_times, new_event_times))
    combined_energies = np.concatenate((remaining_original_energies, reco_energies_to_inject))
    combined_zeniths = np.concatenate((remaining_original_zeniths, new_event_zeniths))
    combined_azimuths = np.concatenate((remaining_original_azimuths, new_event_azimuths))

    sort_indices = np.argsort(combined_times)
    combined_times = combined_times[sort_indices]
    combined_energies = combined_energies[sort_indices]
    combined_zeniths = combined_zeniths[sort_indices]
    combined_azimuths = combined_azimuths[sort_indices]

    # --- Summary Output ---
    if print_summary:
        print("\n--- Signal Injection Summary ---")
        print(f"Total original events:      {total_events}")
        print(f"Simulated (injected) events: {n_events_inject} ({n_events_inject / total_events * 100:.2f}%)")
        print(f"Original events kept:        {num_original_events_to_keep} ({num_original_events_to_keep / total_events * 100:.2f}%)")
        print(f"Combined total events:       {len(combined_times)}")

        # Preview a few combined events
        print(f"\n--- Preview of {preview_n} Random Combined Events ---")
        preview_indices = np.random.choice(len(combined_times), min(preview_n, len(combined_times)), replace=False)
        for idx in preview_indices:
            print(f"[{idx}] Time: {combined_times[idx]:.2f}, Energy: {combined_energies[idx]:.2f}, "
                  f"Zenith: {combined_zeniths[idx]:.2f}, Azimuth: {combined_azimuths[idx]:.2f}")

    return combined_times, combined_energies, combined_zeniths, combined_azimuths



def apply_selection_cuts(event_list, detector, energy_min, energy_max, nhits_tr_min,
                         nhits_sh_min, lik_tr_min, lik_sh_min, beta0_tr_max,
                         zenith_min, trackscore_low_max, trackscore_high_min):
    """Apply a set of selection cuts to a KM3NeT event list."""

    # Energy cut
    energy_mask = (event_list['energy'].value >= energy_min) & (event_list['energy'].value <= energy_max)
    event_list = event_list[energy_mask]

    # Track/Shower event selection
    track_events = (event_list['rec_type'] == kd.reconstruction.JPP_RECONSTRUCTION_TYPE) & \
                   (event_list['rec_stage'] == kd.reconstruction.JMUONBEGIN)

    if detector == 'arca':
        shower_events = (event_list['rec_type'] == kd.reconstruction.AANET_RECONSTRUCTION_TYPE) & \
                        (event_list['rec_stage'] == kd.reconstruction.AASHOWERBEGIN)
        hits_mask_shower = shower_events & (event_list['AASHOWERFIT_NUMBER_OF_HITS'] >= nhits_sh_min)
    elif detector == 'orca':
        shower_events = (event_list['rec_type'] == kd.reconstruction.JPP_RECONSTRUCTION_TYPE) & \
                        (event_list['rec_stage'] == kd.reconstruction.JSHOWERBEGIN)
        hits_mask_shower = shower_events & (event_list['JGANDALF_NUMBER_OF_HITS'] >= nhits_sh_min)
    else:
        raise ValueError(f"Unsupported detector: {detector}")

    # Hits cut
    hits_mask_track = track_events & (event_list['JGANDALF_NUMBER_OF_HITS'] >= nhits_tr_min)
    event_list = event_list[hits_mask_shower | hits_mask_track]

    # Re-derive events post hits cut
    track_events = (event_list['rec_type'] == kd.reconstruction.JPP_RECONSTRUCTION_TYPE) & \
                   (event_list['rec_stage'] == kd.reconstruction.JMUONBEGIN)
    shower_events = (event_list['rec_type'] == kd.reconstruction.AANET_RECONSTRUCTION_TYPE) & \
                    (event_list['rec_stage'] == kd.reconstruction.AASHOWERBEGIN) if detector == 'arca' else \
                    (event_list['rec_type'] == kd.reconstruction.JPP_RECONSTRUCTION_TYPE) & \
                    (event_list['rec_stage'] == kd.reconstruction.JSHOWERBEGIN)

    # Likelihood cut
    lik_mask_track = track_events & (np.abs(event_list['likelihood']) >= lik_tr_min)
    lik_mask_shower = shower_events & (np.abs(event_list['likelihood']) >= lik_sh_min)
    event_list = event_list[lik_mask_track | lik_mask_shower]

    # Zenith cut
    zenith_min_rad = zenith_min * np.pi / 180
    event_list = event_list[event_list['zenith'] >= zenith_min_rad]

    # Beta0 cut (only applies to tracks)
    track_events = (event_list['rec_type'] == kd.reconstruction.JPP_RECONSTRUCTION_TYPE) & \
                   (event_list['rec_stage'] == kd.reconstruction.JMUONBEGIN)
    shower_events = (event_list['rec_type'] == kd.reconstruction.AANET_RECONSTRUCTION_TYPE) & \
                    (event_list['rec_stage'] == kd.reconstruction.AASHOWERBEGIN) if detector == 'arca' else \
                    (event_list['rec_type'] == kd.reconstruction.JPP_RECONSTRUCTION_TYPE) & \
                    (event_list['rec_stage'] == kd.reconstruction.JSHOWERBEGIN)
    beta0_tr_mask = track_events & (event_list['JGANDALF_BETA0_RAD'] <= beta0_tr_max)
    event_list = event_list[beta0_tr_mask | shower_events]

    # Trackscore cut
    trackscore_mask = (event_list['track_score'] <= trackscore_low_max) | \
                      (event_list['track_score'] >= trackscore_high_min)
    event_list = event_list[trackscore_mask]

    return event_list

def extract_subset_within_gtis(event_list, gti_array, desired_length_days):
    """Extract a time-limited subset from event_list, using GTIs to accumulate real live-time."""
    subset_event_indices = []
    accumulated_live_time = 0.0
    used_gtis = []

    event_times = event_list['time']

    if gti_array is not None:
        for start, stop in gti_array:
            gti_duration = stop - start

            if accumulated_live_time + gti_duration > desired_length_days:
                remaining_time = desired_length_days - accumulated_live_time
                new_stop = start + remaining_time
                in_partial_gti = (event_times.value >= start) & (event_times.value < new_stop)
                selected = np.where(in_partial_gti)[0]
                subset_event_indices.extend(selected.tolist())
                used_gtis.append([start, new_stop])
                accumulated_live_time += remaining_time
                break
            else:
                in_gti = (event_times.value >= start) & (event_times.value <= stop)
                selected = np.where(in_gti)[0]
                subset_event_indices.extend(selected.tolist())
                used_gtis.append([start, stop])
                accumulated_live_time += gti_duration

            if accumulated_live_time >= desired_length_days:
                break
    else:
        first_time = event_times[0]
        last_time = first_time + desired_length_days
        in_range = (event_times >= first_time) & (event_times < last_time)
        subset_event_indices = np.where(in_range)[0].tolist()
        used_gtis = [[first_time.value, last_time.value]]
        accumulated_live_time = desired_length_days

    subset = event_list[subset_event_indices]
    return subset, accumulated_live_time, np.array(used_gtis)



def main():

    method = 'base' # str(arguments['--method'])
    length = 60 # float(arguments['--length'])
    phi0 = 7e-11
    gamma = 2.0
    nbins = 32
    frequency = 11

    
    #shower_histo_file = data['shower_histo_file']
    #track_histo_file = data['track_histo_file']



    source_file = "/home/hpc/capn/capn107h/software/psr/workflows/km3net/km3net_analysis/inputs/sources/Vela_X-1.h5"
    input_file = "/home/wecapstor3/capn/capn107h/combined_eventlists/arca_KM3NeT_00000133_0001_combined_4982323events_mc.hdf5"

    aeff_file = "/home/hpc/capn/capn107h/software/psr/src/notebooks/aeff_summary_v9_flavors.hdf5"

    shower_histo_file  = "/home/hpc/capn/capn107h/software/psr/src/notebooks/arca_energy_response_histogram.hdf5pdgid12_-12_16_-16.hdf5"
    track_histo_file = "/home/hpc/capn/capn107h/software/psr/src/notebooks/arca_energy_response_histogram.hdf5pdgid14_-14.hdf5"


    shower_hist2d, shower_bins_true, shower_bins_reco = load_histogram(
        shower_histo_file
    )

    track_hist2d, track_bins_true, track_bins_reco = load_histogram(
        track_histo_file
    )

    file_path_angres_sh = "/home/hpc/capn/capn107h/software/psr/workflows/km3net/km3net_analysis/inputs/angular_res_files/AngularResolutionOverEnergy_aashower_mcv8.1.gsg_anue-CCHEDIS_1e2-1e8GeV.sirene.jterbr00013.hdf5"
    file_path_angres_tr = "/home/hpc/capn/capn107h/software/psr/workflows/km3net/km3net_analysis/inputs/angular_res_files/AngularResolutionOverEnergy_jmuon_mcv8.1.gsg_numu-CCHEDIS_1e2-1e8GeV.sirene.jterbr000132.hdf5"

    fit_func_tr = fit_angular_resolution(file_path_angres_tr,".",2,8,fit_type="logistic")
    fit_func_sh = fit_angular_resolution(file_path_angres_sh,".",2,8,fit_type="polymial")

    aeff_dict = {}
    for flavor in ['nue', 'anue', 'numu', 'anumu', 'nutau', 'anutau']:
        _, aeff_2d, e_bins, cos_theta_bins = load_aeff(aeff_file, flavor)
        aeff_dict[flavor] = aeff_2d


    with h5py.File(source_file, 'r') as f:
        ra = f['skycoord/ra'][()]
        dec = f['skycoord/dec'][()]
        source_skycoord = SkyCoord(ra=ra * u.deg, dec=dec * u.deg)
    
    
    
    input_files = [input_file]
    for idx, file in enumerate(input_files):

        with h5py.File(file) as input_file:
            eventList = Table.read(input_file)
            times = eventList['time'] #.value.astype(float)
            zenith = eventList['zenith'].value.astype(float)
            energy = eventList['energy'].value.astype(float)

            detector_location = get_location('arca')
            observation_times = np.linspace(times.min(), times.max(),1000)
          

            print(f"Max Time: {times.max()}")
            print(f"Min Time: {times.min()}")
            duration = times.max() - times.min()
            duration_days = duration/(24.0*3600.0)
            print(f"Duration: {duration} s - {duration_days} d")
            n_events = len(times)
            print(f"Number of Events: {n_events}")
            rate_max = 1.0*n_events/duration_days
            print(f"Max Rate: {rate_max} 1/d")


            energies, n_total, n_em_showers, event_df, shower_energies, track_energies = simulate_events_all_flavors(
                phi0=phi0,
                energy_bins=e_bins,
                theta_bin_edges=np.arccos(cos_theta_bins[::-1]),  # Important: convert cos(theta) to theta
                aeff_dict=aeff_dict,
                source_coord=source_skycoord,
                times=observation_times,
                location=detector_location,
                days=90,
                gamma=gamma,
                plot=True
            )
            
            reco_shower_energies, failed_shower = sample_reco_energy_array(
                shower_energies, shower_hist2d, shower_bins_true, shower_bins_reco
            )

            reco_track_energies, failed_track = sample_reco_energy_array(
                track_energies, track_hist2d, track_bins_true, track_bins_reco
            )

            df_showers = pd.DataFrame({
                'true_energy': shower_energies,
                'reco_energy': reco_shower_energies,
                'type': 'shower'
            })

            # Track events
            df_tracks = pd.DataFrame({
                'true_energy': track_energies,
                'reco_energy': reco_track_energies,
                'type': 'track'
            })

            df_combined = pd.concat([df_showers, df_tracks], ignore_index=True)

            reco_combined_energies = np.concatenate((reco_track_energies, reco_shower_energies))
            combined_energies = np.concatenate((track_energies, shower_energies))



            injected_energies = df_combined['reco_energy']
            injected_reco_types = df_combined['type']
                
            combine_times, combined_energies, combined_zeniths, combined_azimuths = inject_signal_times(
                time=eventList['time'].value.astype(float),
                energy=eventList['energy'].value.astype(float),
                zenith=eventList['zenith'],
                azimuth=eventList['azimuth'],
                reco_energies_to_inject=injected_energies,
                reco_types_to_inject = injected_reco_types,
                bin_time=1e-5,
                pulseshape='mvm',
                frequency=frequency,
                baseline=0.0,
                a=1.0,
                phi=0.0,
                method='base',
                kappa=5.0,
                skycoord=source_skycoord,
                detector_location=detector_location,
                track_resolution_func = fit_func_tr,
                shower_resolution_func = fit_func_sh
            )


            TimeEventList= TimeSeries(time=Time(combine_times, format='unix'))
            InjectedEventList = eventList.copy()
            InjectedEventList['time'] = TimeEventList['time']
            InjectedEventList['energy'] = combined_energies #* EventList['energy'].unit
            InjectedEventList['zenith'] = combined_zeniths
            InjectedEventList['azimuth'] = combined_azimuths

            cut_params = {
                'detector': 'arca',
                'energy_min': 1e2,
                'energy_max': 1e8,
                'nhits_tr_min': 20,
                'nhits_sh_min': 20,
                'lik_tr_min': 50.,
                'lik_sh_min': 50.,
                'beta0_tr_max': 1,
                'zenith_min': 0,
                'trackscore_low_max': 0.5,
                'trackscore_high_min': 0.5,
            }

            InjectedEventListWithCuts = apply_selection_cuts(InjectedEventList, **cut_params)
            print(f"All cuts applied.")
            current_gti = None
            # Extract the GTI-respecting subset
            InjectedEventListWithCutsSubset, used_live_time, used_gtis = extract_subset_within_gtis(InjectedEventListWithCuts, current_gti, length)

            used_live_time_seconds = used_live_time *(24.0*3600.0)
            print(f"New Amount of Events for {used_live_time:.2f} days ({used_live_time_seconds:.2f} s): {len(InjectedEventListWithCutsSubset['time'])}")

            InjectedEventListWithCutsSubset.meta['length'] = length


            
            output_file_table =  'NewTestRun_mvm_Emin'  + str(phi0) + 'g' + str(gamma)
           
            write_data = False

            if write_data is True:
                with h5py.File(output_file_table, 'w') as output:
                    InjectedEventListWithCutsSubset.write(output, format='hdf5', overwrite=True, serialize_meta=True)
                print(f"File written to: {output_file_table}")

            
            FinalEventList= TimeSeries(time=Time(InjectedEventListWithCutsSubset['time'], format='unix'))

            print(f"Times: {np.array(FinalEventList['time'].value)}")
            frequencies = get_testfrequencies(11,1000, 5e-9)

            print(f"First 10 Times: {[f'{x:.3f}' for x in np.array(FinalEventList['time'].value)[:10]]}")
            print(f"Last 10 Times: {[f'{x:.3f}' for x in np.array(FinalEventList['time'].value)[-10:]]}")
            print(f"Number of available events: {len(np.array(FinalEventList['time'].value))}")
            print(f"Test frequencies: {frequencies}")
            print(f"nbins: {nbins}")
            print(f"used_gtis: {used_gtis}")

            freq, efstat = epoch_folding_search(
                np.array(FinalEventList['time'].value),
                frequencies,
                nbin=nbins,
                segment_size=1e10,
                gti=used_gtis
            ) 
            plot = True
            output_plot_ef = "Testplot_ef.png"
            if plot is True:
                plt.figure()
                plt.plot(freq, efstat, label='EF statistics', alpha=0.8)
                plt.axhline(nbins - 1, ls='--', lw=3, color='k', label='n - 1')
                plt.axvline(11, lw=3, alpha=0.5, color='r', label='Correct frequency')
                plt.xlabel('Frequency (Hz)')
                plt.ylabel('EF Statistics')
                _ = plt.legend()

                threshold = (np.max(efstat)*0.1+ nbins - 1)
                best_x, best_y = search_best_peaks(freq,efstat,threshold)
                y_min, y_max = plt.ylim()
                offset = 0.04 * (y_max - y_min)

                plt.savefig(output_plot_ef)
                print(f"Plot saved: {output_plot_ef}")

            #print(f"Plot saved: {output_plot_ef}")
            output_file_ef = "Testfile_ef.hdf5"
            with h5py.File(output_file_ef, 'w') as out:
                savehdf5(freq, efstat, out)
                print(f"File saved: {output_file_ef}")



if __name__ == "__main__":
    main()